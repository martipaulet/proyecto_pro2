var searchData=
[
  ['decreasenumusersin',['DecreaseNumUsersIn',['../class_course.html#ab23d9a5201da47a27d9b307a5889ca23',1,'Course::DecreaseNumUsersIn()'],['../class_course_set.html#ab24913a21a3fd64d67346668dbf9159c',1,'CourseSet::DecreaseNumUsersIn()']]],
  ['delete',['Delete',['../class_user_set.html#a9a548c48abafd33e8460d9e8a9e40170',1,'UserSet']]]
];
