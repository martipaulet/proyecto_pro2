var searchData=
[
  ['baja_5fusuario',['BAJA_USUARIO',['../main_8cc.html#ada16e2b27577b1205b7cb1f67c1b7dfe',1,'main.cc']]]
];
