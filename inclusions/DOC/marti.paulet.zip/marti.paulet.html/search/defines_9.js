var searchData=
[
  ['sesion_5fproblema',['SESION_PROBLEMA',['../main_8cc.html#ab607cfb91162b0667ab571d439b77e3d',1,'main.cc']]]
];
