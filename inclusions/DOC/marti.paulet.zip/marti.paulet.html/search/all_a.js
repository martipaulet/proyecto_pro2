var searchData=
[
  ['nueva_5fsesion',['NUEVA_SESION',['../main_8cc.html#a03b4a401073c8465967a2490e4255103',1,'main.cc']]],
  ['nuevo_5fcurso',['NUEVO_CURSO',['../main_8cc.html#a23117f1ffed13aa567c085989e0b687b',1,'main.cc']]],
  ['nuevo_5fproblema',['NUEVO_PROBLEMA',['../main_8cc.html#a77947d50d33173dbb8d2203ae806430f',1,'main.cc']]]
];
