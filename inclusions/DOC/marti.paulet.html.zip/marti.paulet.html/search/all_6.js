var searchData=
[
  ['getcurso',['GetCurso',['../class_user.html#a7e91af81476c9ae37cd2bad99862fc8f',1,'User::GetCurso()'],['../class_user_set.html#a20c73031d173fac4db788598ea20ce79',1,'UserSet::GetCurso()']]],
  ['getenviosexito',['GetEnviosExito',['../class_problem.html#aff1a49d7c06873886905fc01b5ca024c',1,'Problem::GetEnviosExito()'],['../class_problem_set.html#aaf4917f4ebb7dc317ca91f1ecdbc2fe9',1,'ProblemSet::GetEnviosExito()']]],
  ['getenviostotales',['GetEnviosTotales',['../class_problem.html#af97fede267d1b9881854f7d8da7be49a',1,'Problem::GetEnviosTotales()'],['../class_problem_set.html#a33746a7a5aefdce5a4e8a5bf597c84f1',1,'ProblemSet::GetEnviosTotales()']]],
  ['getnumproblems',['GetNumProblems',['../class_sesion.html#ad770a0d4c75b0b2d70fa6c5cdcf336ec',1,'Sesion::GetNumProblems()'],['../class_sesion_set.html#afeb85dad709e3fc5717e93c05a24bf8f',1,'SesionSet::GetNumProblems()']]],
  ['getnumusersdone',['GetNumUsersDone',['../class_course.html#ad17501c45b744c632235c05365f05f1d',1,'Course::GetNumUsersDone()'],['../class_course_set.html#a46150057534a76182941f23beb2ce4cc',1,'CourseSet::GetNumUsersDone()']]],
  ['getnumusersin',['GetNumUsersIn',['../class_course.html#a3ce2bc364698f6857385d7bb0ea82812',1,'Course::GetNumUsersIn()'],['../class_course_set.html#a72b6a09b4eafce672b57abebfa9f1f55',1,'CourseSet::GetNumUsersIn()']]],
  ['getproblemid',['GetProblemId',['../class_problem.html#a953ef8047cd489d36f4a96d10baed4af',1,'Problem::GetProblemId()'],['../class_problem_set.html#a8fd763c7dbee07a8f0101119f23e694a',1,'ProblemSet::GetProblemId()']]],
  ['getproblemsid',['GetProblemsId',['../class_sesion.html#af8f21957c77c2a3f7a1f923f2779cc41',1,'Sesion::GetProblemsId()'],['../class_sesion_set.html#a40ab167ffeda96c90a899c669b7c8a7c',1,'SesionSet::GetProblemsId()']]],
  ['getratio',['GetRatio',['../class_problem.html#a6aceef9e936ee16ef8368803f22a0268',1,'Problem::GetRatio()'],['../class_problem_set.html#aae2358d2149c1f703d97f2882ae2bec6',1,'ProblemSet::GetRatio()']]],
  ['getsesion',['GetSesion',['../class_course.html#a56a7f6bfd9dcd415c35246b2dc4afddb',1,'Course::GetSesion()'],['../class_course_set.html#a534fa228ab549072198b0966d159a530',1,'CourseSet::GetSesion()']]],
  ['getsesionid',['GetSesionId',['../class_sesion.html#a9f3c532f36fb49a6caa5dd82b9ee9a3f',1,'Sesion::GetSesionId()'],['../class_sesion_set.html#a0c84ef607240e540fd1bcaec68280636',1,'SesionSet::GetSesionId()']]],
  ['getsolvedproblems',['GetSolvedProblems',['../class_user.html#a4dc2fc233119ddda449099634f4d2c46',1,'User']]],
  ['gettotalsends',['GetTotalSends',['../class_user.html#aa9e61fa20b935204897891e161a75286',1,'User']]],
  ['gettryedproblems',['GetTryedProblems',['../class_user.html#a8c4799a9a4bfa78fbe289f845deaccb1',1,'User']]]
];
