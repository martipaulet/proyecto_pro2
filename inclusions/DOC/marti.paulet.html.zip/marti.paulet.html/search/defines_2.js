var searchData=
[
  ['curso_5fusuario',['CURSO_USUARIO',['../main_8cc.html#afa5e5ac0bff79d08b37a01b05c26c4a7',1,'main.cc']]]
];
