var searchData=
[
  ['problemas_5fenviables',['PROBLEMAS_ENVIABLES',['../main_8cc.html#a55393525f368bcb01300b5a8ac6fc26d',1,'main.cc']]],
  ['problemas_5fresueltos',['PROBLEMAS_RESUELTOS',['../main_8cc.html#aa1bd243bac28c37c95e9e75af147a75b',1,'main.cc']]]
];
