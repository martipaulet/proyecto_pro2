var searchData=
[
  ['listar_5fcursos',['LISTAR_CURSOS',['../main_8cc.html#a6b65544bd990c1e167bacb4114190445',1,'main.cc']]],
  ['listar_5fproblemas',['LISTAR_PROBLEMAS',['../main_8cc.html#a386b604b5bbf5bef1a63fefca032c689',1,'main.cc']]],
  ['listar_5fsesiones',['LISTAR_SESIONES',['../main_8cc.html#a51fa60d02e939c134b36fd61cb5c041b',1,'main.cc']]],
  ['listar_5fusuarios',['LISTAR_USUARIOS',['../main_8cc.html#af56aa947fd7bd388c7cc8da566643a34',1,'main.cc']]]
];
